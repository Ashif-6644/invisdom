# INVISDOM AI — Food Personality Challenge

Created by Mohamed Ashif (@invisible_startdom).

A free, mobile-friendly 8-question food personality game. This release is rule-based and does **not** call an AI API. It needs no hosting backend or API keys.

## Publish manually to GitHub Pages

1. Sign in to https://github.com and click **New repository**.
2. Repository name: `invisdom-ai` (or another available name). Set it to **Public**.
3. Select **Add file → Upload files**. Upload `index.html` from this folder to the repository root. Optionally add `README.md`. Commit the changes.
4. Open the repository's **Settings → Pages**. In **Build and deployment**, select **Deploy from a branch**, branch **main**, folder **/(root)**. Save.
5. Open the Pages URL shown by GitHub: `https://YOUR-USERNAME.github.io/invisdom-ai/`.
6. Test the quiz and share button on mobile before posting the link on LinkedIn.

## Notes
- The browser runs all questions and calculates results locally. No answers are uploaded or retained.
- The result is a playful personality quiz, not health or medical advice.
- To add actual AI-generated results later, use a secure server-side proxy/API; **never** publish your AI API key inside `index.html` or GitHub Pages.
